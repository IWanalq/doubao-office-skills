# 豆包官方帮助中心手册-beta版本（本地摘录索引）

来源 URL：https://lf9-cdn-tos.draftstatic.com/obj/ies-hotsoon-draft/grace_legal/doubao_member_copywrite_for_ai.html

本 Skill 已将官方网页正文按主题拆分为以下主查询资料。回答问题时先按用户意图读取对应文件；跨主题或不确定时可读取多个文件。若需要确认最新变化，应重新访问来源 URL。

## 目录

- `doubao-pro-membership-plans.md`：豆包专业版套餐与定价、额度与用量、开通购买。
- `doubao-pro-membership-support.md`：豆包专业版退款财务、购买后异常、跨端与账号管理、投诉类问题、AI 能力边界、豆包手机助手。
- `doubao-privacy-data.md`：聊天记录保存/删除/恢复、记忆清空、数据用于模型训练或优化、位置/IP/个人信息来源、隐私泄露质疑、聊天记录异常。
- `doubao-memory.md`：记忆功能简介、工作原理、管理与操作方式、隐私保护机制、投诉反馈、记忆 FAQ、功能边界和隐私安全。
